const express = require('express')

const home = async (req,res)=>{

res.status(200).json(req.user)
console.log(req.user)

}

module.exports = {home}